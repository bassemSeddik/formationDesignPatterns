package Employee;

public class EmployeeController {
	private Employee model;
	private EmployeeView view;

	public EmployeeController(Employee model, EmployeeView view) {
		System.out.println("-+| new controller created |+-");

		this.model = model;
		this.view = view;
	}
	// Notice the call to the model to perform the intraction with name
	public void setEmployeeName(String name) {
		model.setName(name);
	}
	public String getEmployeeName() {
		return model.getName();
	}
	
	//Notice the call to the model to perform the intraction with company
	public void setEmployeeCompany(String rollNo) {
		model.setCompany(rollNo);
	}
	public String getEmployeeCompany() {
		return model.getCompany();
	}

	public void updateView() {
		view.printEmployeesDetails(model.getName(), model.getCompany());
	}
}
