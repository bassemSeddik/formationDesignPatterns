package Employee;

public class Program {
	public static void main(String[] args) {

		// fetch student record based on his roll no from the database
		Employee model = retriveEmployeesFromDatabase();
		// Create a view : to write student details on console
		EmployeeView view = new EmployeeView();
		EmployeeController controller = new EmployeeController(model, view);
		controller.updateView();
		
		// update model data
		controller.setEmployeeCompany("INETUM");
		controller.updateView();
	}

	private static Employee retriveEmployeesFromDatabase() {
		System.out.println("> NOW WE READ DATA FROM SOURCE <");
		Employee employee = new Employee();
		employee.setName("Robert");
		employee.setCompany("Atlas_Corp");
		return employee;
	}
}
