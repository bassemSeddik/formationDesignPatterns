package magasin;

import java.math.BigDecimal;

public class OrderController {
    private StoreOrder storeOrder;
    private OrderView orderView;
    
    public OrderController(StoreOrder storeOrder, OrderView orderView) {
        this.storeOrder = storeOrder;
        this.setOrderView(orderView);
    }
    
    public void deleteItem( int itemNum ) {
        storeOrder.deleteItem( itemNum );
    }
    
    public void changePrice( int itemNum, Integer newPrice ) {
        storeOrder.changePrice( itemNum, newPrice );
    }

	public OrderView getOrderView() {
		return orderView;
	}

	public void setOrderView(OrderView orderView) {
		this.orderView = orderView;
	}
}
