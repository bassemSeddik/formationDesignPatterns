package magasin;

import java.math.BigDecimal;

public class Program {

	public static void main(String [] args) {
		//Get the model
	    StoreOrder model  = new StoreOrder();
	    model.addItem(2);
	    model.addItem(1);
	    
	    
	    //Create a view 
	    OrderView view = new OrderView();
	    
	    // make the link
	    OrderController controller = new OrderController(model, view);

	}
}
