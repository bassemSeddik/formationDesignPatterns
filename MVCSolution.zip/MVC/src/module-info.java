module MVC {
	requires java.desktop;
}