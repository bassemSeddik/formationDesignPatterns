package Polymorphisme;

public class Chien extends Animal {

	public Chien(String nom) {
		super(nom);
		System.out.println("chien creation");
	}

	@Override
	public void Parler() {
		System.out.println("OUAF OUOUF!, je suis " + this.getNom());
	}
}
