package Polymorphisme;

public class Program {
	public static void main(String[] args) {
		Chat chat1 = new Chat("Minouch");
		Chien chien1 = new Chien("Pluto");

		chat1.Parler();
		chien1.Parler();
	}
}
