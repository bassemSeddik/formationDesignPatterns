package magasin;

import java.math.BigDecimal;
import java.util.*;
import javax.swing.*;

import java.awt.FlowLayout;
import java.awt.event.*;

public class OrderView extends JPanel implements Observer, ActionListener {

	// Controller
    private OrderController controller;
    // User-Interface Elements
    private JFrame frame;
    private JButton changePriceButton;
    private JButton deleteItemButton;
    private JTextField newPriceField;
    private JLabel totalLabel;
    private JTable groceryList;
    private void createUI() {
        // Initialize UI elements. e.g.:
    	
    	JPanel panel = new JPanel();
    	panel.setLayout(new FlowLayout());
        deleteItemButton = new JButton("Delete Item");
        panel.add(deleteItemButton);
        //setContentPane(panel);
        setSize(200,100);
        setVisible(true);
        //...  // Add listeners. e.g.:
        deleteItemButton.addActionListener(this);
        //...
    }
    
    public void update ( Observable s, Object arg ) {
        display(((StoreOrder) s).getItemList(), ((StoreOrder) s).getPriceList());
    }
//    public OrderView(OrderController controller) {
//        this.controller = controller;
//        createUI();
//    }
    public OrderView() {
        //this.controller = controller;
        createUI();
    }
    public void display ( ListIterator<String> listIterator, ListIterator<Integer> listIterator2 ) {
        // code to display order
        //...
    }
    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == deleteItemButton) {
            controller.deleteItem(groceryList.getSelectedRow() );
        }
        else if (event.getSource() == changePriceButton) {
        	Integer newPrice = new Integer(newPriceField.getText());
            controller.changePrice(groceryList.getSelectedRow(),newPrice);
        }
    }
}
