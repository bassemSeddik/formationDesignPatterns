package magasin;

import java.math.BigDecimal;
import java.util.*;

@SuppressWarnings("deprecation")
public class StoreOrder extends Observable {

	private ArrayList<String> itemList;
	private ArrayList<Integer> priceList;

	public StoreOrder() {
		itemList = new ArrayList<String>();
		priceList = new ArrayList<Integer>();
	}

	public String getItem(int itemNum) {
		return itemList.get(itemNum);
	}
	public Integer getPrice(int itemNum) {
		return priceList.get(itemNum);
	}
	public ListIterator<String> getItemList() {
		ListIterator<String> itemItr = itemList.listIterator();
		return itemItr;
	}
	public ListIterator<Integer> getPriceList() {
		ListIterator<Integer> priceItr = priceList.listIterator();
		return priceItr;
	}

	@SuppressWarnings("deprecation")
	public void deleteItem(int itemNum) {
		itemList.remove(itemNum);
		priceList.remove(itemNum);
		setChanged();
		notifyObservers();
	}

	@SuppressWarnings("deprecation")
	public void addItem(int barcode) {
		// code to add item (exp. used from a scanner)
		itemList.add(String.valueOf(barcode));
		setChanged();
		notifyObservers();
	}

	@SuppressWarnings("deprecation")
	public void changePrice(int itemNum, Integer newPrice) {
		priceList.set(itemNum, newPrice);
		setChanged();
		notifyObservers();
	}
}
