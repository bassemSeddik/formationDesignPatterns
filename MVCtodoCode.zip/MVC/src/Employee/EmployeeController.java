package Employee;

public class EmployeeController {
	private Employee model;
	private EmployeeView view;

	public EmployeeController(Employee model, EmployeeView view) {
		System.out.println("-+| new controller created |+-");

		this.model = model;
		this.view = view;
	}
	// Notice the call to the model to perform the intraction with name
	public void setEmployeeName(String name) {
		// TODO
	}
	public String getEmployeeName() {
		// TODO
	}
	
	//Notice the call to the model to perform the intraction with company
	public void setEmployeeCompany(String rollNo) {
		// TODO
	}
	public String getEmployeeCompany() {
		// TODO
	}

	public void updateView() {
		view.printEmployeesDetails(model.getName(), model.getCompany());
	}
}
