package Employee;

public class EmployeeView {
	public EmployeeView() {
		System.out.println("-+ new view created +-");
	}
	public void printEmployeesDetails(String employeeName, String employeeCompany) {
		System.out.println("\nEmployee details dislay: ");
		System.out.println("Name: " + employeeName);
		System.out.println("Roll No: " + employeeCompany);
	}
}