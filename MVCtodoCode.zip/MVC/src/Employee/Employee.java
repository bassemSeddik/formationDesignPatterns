package Employee;

public class Employee {
	private String company;
	private String name;

	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Employee() {
		System.out.println("- new empolyee created -");
	}

}
