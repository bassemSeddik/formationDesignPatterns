package Employee;

public class Program {
	public static void main(String[] args) {

		// fetch employee record  from the database
		Employee model = retriveEmployeesFromDatabase();
		// Create a view : to write Employee details on console
		// TODO 
		
		// complete the example with the controller operations
		// TODO
		
		controller.updateView();
	}

	private static Employee retriveEmployeesFromDatabase() {
		System.out.println("> NOW WE READ DATA FROM SOURCE <");
		Employee employee = new Employee();
		employee.setName("Robert");
		employee.setCompany("Atlas_Corp");
		return employee;
	}
}
