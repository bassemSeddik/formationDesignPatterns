package vendingMachineState;

public class OutOfStockState implements State {
	/**
	 * If: We are on the OutOfStockState, and the insertDollar() is Triggered Then:
	 * The machine stays here and outputs a message!
	 */
	public void insertDollar(VendingMachine vendingMachine) {
		vendingMachine.doReturnMoney();
		System.out.println(">The stock is empty! No need to insert money... EJECT");
		vendingMachine.getOutOfStockState();
	}

	/**
	 * If: We are on the OutOfStockState, and the ejectMoney() is Triggered Then:
	 * The machine stays here and outputs a message!
	 */
	public void ejectMoney(VendingMachine vendingMachine) {
		System.out.println(">The stock is empty! money EJET");
	}

	/**
	 * If: We are on the OutOfStockState, and the dispense() is Triggered Then:
	 * The machine stays here and outputs a message!
	 */
	public void dispense(VendingMachine vendingMachine) {
		System.out.println(">The stock is empty! No product to dispense back");
	}
}
