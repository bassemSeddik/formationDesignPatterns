package vendingMachineState;

/**
 * @author Bassem
 *
 */
public class VendingMachine {
	private State idleState;
	private State hasOneDollarState;
	private State outOfStockState;

	private State currentState;
	private int count;

	
	/**
	 * @param count: sets the number of products in the machine.
	 * and thus, the state that it adopts from the start
	 */
	public VendingMachine(int count) {
		System.out.println("\n---- A new vending machine is placed in service ----");
		// make the required States
		idleState = new IdleState();
		hasOneDollarState = new HasOneDollarState();
		outOfStockState = new OutOfStockState();
		this.count = count;
		
		if (count > 0) {
			currentState = idleState;
		} else {
			currentState = outOfStockState;
		}
	}

	// count getters and setters
	public void setCount(int c) {
		this.count = c;
	}
	public int getCount() {
		return this.count;
	}

	// Now we set and display the state ---------------------------
	public void setState(State state) {
		currentState = state;
	}
	public State displayState() {
		System.out.println("|_ we are now in " + currentState.getClass().toString());
		return currentState;
	}

	// Here  we get the different states
	public State getHasOnDollarState() {
		currentState = hasOneDollarState;
		return currentState;
	}
	public State getIdleState() {
		currentState = idleState;
		return currentState;
	}
	public State getOutOfStockState() {
		currentState = outOfStockState;
		return currentState;
	}
	// --------------------------------------------------

	public void insertDollar() {
		System.out.println("Money insertion operation");
		currentState.insertDollar(this);
	}

	public void ejectMoney() {
		System.out.println("Money ejection demand");
		currentState.ejectMoney(this);
	}

	public void dispense() {
		System.out.println("Product dispense demand");
		currentState.dispense(this);
	}

	public void doReturnMoney() {
		System.out.println("Money return applied in anwser");
		setState(idleState);
	}

	public void doReleaseProduct() {
		System.out.println("Product release applied in anwser");
		if (count>1) {
			setCount(count--);
			setState(hasOneDollarState);
		}else {
			setState(outOfStockState);
		}
		
	}
}
