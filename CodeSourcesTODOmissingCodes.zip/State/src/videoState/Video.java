package videoState;

class Video {
	private EtatVideo etatVideo;
	
    public void setState(EtatVideo newEtat) {
        this.etatVideo = newEtat;
    }

    public void action() {
    	etatVideo.action(this);
    }
}











