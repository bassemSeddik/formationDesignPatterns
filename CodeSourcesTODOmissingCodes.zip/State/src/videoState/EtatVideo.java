package videoState;

interface EtatVideo {
    void action(Video context);
}