package videoNoState;


public class Program{
	public static void main(String args[]){
		Video video = new Video();

		video.setEtat("PLAY");
		video.action();

		video.setEtat("PAUSE");
		video.action();
	}
}