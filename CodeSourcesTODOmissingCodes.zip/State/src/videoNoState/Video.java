package videoNoState;

class Video {

	private String etat="";

	public void setEtat(String etat){
		this.etat=etat;
	}

	public void action(){
		if(etat.equalsIgnoreCase("PLAY")){
			System.out.println("La vid�o est en lecture");
		}else if(etat.equalsIgnoreCase("PAUSE")){
			System.out.println("La vid�o est en pause");
		}
	}
}

