package factoryMethod;

public class ChefsKnife extends Knife{
	public void Sharpen() {
		System.out.println("The ChefsKnife is Sharpened");
	}
	
	public void Polish() {
		System.out.println("The ChefsKnife is Polished");
	}
	
	public void Pack() {
		System.out.println("The ChefsKnife is Packed");
	}

	public ChefsKnife() {
		super();
		System.out.println("------------- A ChefsKnife -----------");
	}
	
}
