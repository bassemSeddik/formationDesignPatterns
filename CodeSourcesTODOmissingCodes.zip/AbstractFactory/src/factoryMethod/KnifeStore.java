package factoryMethod;

public class KnifeStore {
	//Welcome to our Knives Store, here is the call to the factory in the main program
	private KnifeFactory factory;
	
	public KnifeFactory getFactory() {
		return factory;
	}

	public void setFactory(KnifeFactory factory) {
		this.factory = factory;
	}

	public KnifeStore(KnifeFactory factory) {
		this.factory = factory;
	}
	
	public Knife OrderKnife(String OrderKnife) {
		Knife knife ;
		
		knife = factory.createKnife(OrderKnife); // the delegation to the factory is here
		
		knife.Sharpen();
		knife.Polish();
		knife.Pack();
		
		return knife;
	}
	
	public static void main(String[] args) {
		// TODO .....

	}

}
