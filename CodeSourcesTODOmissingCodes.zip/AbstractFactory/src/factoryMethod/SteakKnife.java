package factoryMethod;

public class SteakKnife extends Knife{
	public void Sharpen() {
		System.out.println("The SteakKnife is Sharpened");
	}
	
	public void Polish() {
		System.out.println("The SteakKnife is Polished");
	}
	
	public void Pack() {
		System.out.println("The SteakKnife is Packed");
	}

	public SteakKnife() {
		super();
		System.out.println("------------- A SteakKnife -----------");
	}	
}
