package abstractFactory;

public class BudgetKnifeStore  {
	// Nous avons besoin d'une instance de notre usine pour la faire fonctionner
	private BudgetKnifeFactory budgetFactory;
	public BudgetKnifeStore(BudgetKnifeFactory factroy) {
		this.setBudgetFactory(factroy);
	}
	public BudgetKnifeFactory getBudgetFactory() {
		return budgetFactory;
	}
	public void setBudgetFactory(BudgetKnifeFactory budgetFactory) {
		this.budgetFactory = budgetFactory;
	}
	
	public Knife orderKnife(String knifeType) {
		Knife knife;
		// now creating a knife is a method in the class 
		knife = budgetFactory.createKnife(knifeType);
		
		knife.Sharpen();
		knife.Polish();
		knife.Pack();
		return knife;
	}
}
