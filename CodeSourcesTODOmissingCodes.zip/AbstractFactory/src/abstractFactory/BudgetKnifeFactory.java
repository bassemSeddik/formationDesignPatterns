package abstractFactory;

public class BudgetKnifeFactory extends AbstractKnifeFactory {
	@Override
	Knife createKnife(String knifeType) {
		// up to any subclass of BudgetKnifeStore to define this method
		if (knifeType.equals("cheeze")) {
			return new BudgetCheezeKnife();
		} else if (knifeType.equals("bread")) {
			return new BudgetBreadKnife();
		}
		// .. more types
		else
			return null;
	}
}
