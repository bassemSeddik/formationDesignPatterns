package abstractFactory;

public class LuxuryCakeKnife extends Knife {
	public void Sharpen() {
		System.out.println("The LuxuryCakeKnife is Sharpened");
	}
	
	public void Polish() {
		System.out.println("The LuxuryCakeKnife is Polished");
	}
	
	public void Pack() {
		System.out.println("The LuxuryCakeKnife is Packed");
	}

	public LuxuryCakeKnife() {
		super();
		System.out.println("------------- A LuxuryCakeKnife -----------");
	}
}
