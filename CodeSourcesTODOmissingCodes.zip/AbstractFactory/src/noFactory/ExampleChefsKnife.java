package noFactory;

public class ExampleChefsKnife extends Knife{
	public void Sharpen() {
		System.out.println("The ChefsKnife is Sharpened");
	}
	
	public void Polish() {
		System.out.println("The ChefsKnife is Polished");
	}
	
	public void Pack() {
		System.out.println("The ChefsKnife is Packed");
	}

	public ExampleChefsKnife() {
		super();
		System.out.println("------------- A ChefsKnife -----------");

	}
	
}
