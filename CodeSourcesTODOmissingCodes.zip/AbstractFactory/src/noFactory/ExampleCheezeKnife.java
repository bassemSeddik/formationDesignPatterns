package noFactory;

public class ExampleCheezeKnife extends Knife{
	public void Sharpen() {
		System.out.println("The CheezeKnife is Sharpened");
	}
	
	public void Polish() {
		System.out.println("The CheezeKnife is Polished");
	}
	
	public void Pack() {
		System.out.println("The CheezeKnife is Packed");
	}

	public ExampleCheezeKnife() {
		super();
		System.out.println("------------- A SteakKnife -----------");

	}
	
}
