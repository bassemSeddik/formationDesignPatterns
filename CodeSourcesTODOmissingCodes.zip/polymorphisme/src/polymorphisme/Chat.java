
package polymorphisme ;

public class Chat extends Animal {

	public Chat(String nom) {
		super(nom);
		System.out.println("chat creation");
	}

	@Override
	public void Parler() {
		System.out.println("Miaou!, je suis " + this.getNom());
	}
}
