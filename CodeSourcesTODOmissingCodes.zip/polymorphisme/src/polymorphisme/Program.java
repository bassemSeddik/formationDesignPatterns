package polymorphisme ;

public class Program {
	public static void main(String[] args) {
		//  TODO make a working example
	}
}
