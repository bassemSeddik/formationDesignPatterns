package pasta;

public abstract class PastaDish {
	
	/**
	 * Notice that the makeRecipe() method is public and final
	 * so that the other dishes can use it, but without any change
	 */
	public final void makeRecipe()
    {
		System.out.println(" ----- NEW DISH START ------");
        // Complete the list of methods to add
    }

    protected abstract void AddPasta();
    protected abstract void AddSauce();
    protected abstract void AddProtein();
    protected abstract void AddGarnish();

    private void BoilWater()
    {
        System.out.println("> Boiling water");
    }

    private void CookPasta()
    {
    	System.out.println("> Cooking the Pasta!");
    }

    private void DrainAndPlate()
    {
    	System.out.println("> Draining and Plating the Dish!");
    }

}
