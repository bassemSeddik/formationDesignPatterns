package facadeClientAccount;

import java.math.BigDecimal;
import java.util.*;  

public class BankServiceFacade {
	
	/**
	 * The HashTable allows simply to link a key to a value. 
	 * In this case, we link a set of account numbers to the
	 * relative Account wrapped by the interface IAccount 
	 */
	
	private Hashtable<Integer, IAccount> bankAccounts;
	
	public BankServiceFacade() {
		this.bankAccounts = new Hashtable<Integer, IAccount>();
	}
	
	public int createNewAccount(String type, BigDecimal initAmount) {
		IAccount newAccount = null;
		switch (type) {
		case "chequing":
			newAccount = new Chequing(initAmount);
			break;
		case "saving":
			newAccount = new Saving(initAmount);
			break;
		case "investment":
			newAccount = new Investment(initAmount);
			break;
		default:
			System.out.println("Invalid account type");
			break;
		}
		if (newAccount != null) {
			this.bankAccounts.put(newAccount.getAccountNumber(), newAccount);
			return newAccount.getAccountNumber();
		}
		return -1;
	}
	public void transferMoney(int to, int from, BigDecimal amount) {
		IAccount toAccount = this.bankAccounts.get(to);
		IAccount fromAccount = this.bankAccounts.get(from);
		//fromAccount.transfer(toAccount, amount);
		fromAccount.transfer(amount);
	}
}
