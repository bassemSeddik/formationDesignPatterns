package webAdapter;

import org.json.simple.JSONObject;

public class WebService {
	String webServiceName;
	
	public WebService(String name) {
		this.webServiceName = name;
	}
	
	public JSONObject request(JSONObject result) {
		// TODO Auto-generated method stub
		return null;
	}
}
