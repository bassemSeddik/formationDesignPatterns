package webAdapter;

public interface WebRequester {
	// TODO ...
}
