package propertyChangeListener;

public class Program {

	public static void main(String[] args) {
		PCLNewsAgency observable = new PCLNewsAgency();
		PCLNewsChannel observer = new PCLNewsChannel();

		observable.addPropertyChangeListener(observer);
		observable.setNews("The oldest school in country is renewed");
		observable.setNews("The holidays are over");

		//assertEquals(observer.getNews(), "news");
		System.out.println(observer.getNews().toString());
	}

}
