package youtubeObserver;

public class Program {
	public static void main(String[] args) {
		//Create new channel without new videos
        Channel observedChannel = new Channel("Daft_Punk", "didn't post any new videos");

        // TODO, define a set of observers
        
        System.out.println("Videos update : " + observedChannel.getStatus());
        System.out.println();
        // DP channel posted a new video
        observedChannel.setStatus(">A new Song is Rocking: ... Around the World! Around the World!");
	}
}
