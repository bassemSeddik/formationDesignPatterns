package youtubeObserver;

public interface Observer {
	void update(String status);
}
