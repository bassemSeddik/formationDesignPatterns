package youtubeObserver;

import java.util.ArrayList;

public class Channel implements Subject {
	private ArrayList<Observer> fans = new ArrayList<Observer>();
	private String ChannelName;
	private String Status;
	
	// Methods overrides from the reference Subject Interface
	@Override
	public void RegisterObserver(Observer fan) {
		System.out.println("Observer Added : " + ((Follower) fan).UserName);
		fans.add(fan);
	}
	@Override
	public void RemoveObserver(Observer fan) {
		System.out.println("Observer Removed : " + ((Follower) fan).UserName);
		fans.remove(fan);
	}
	@Override
	public void NotifyObservers() {
        System.out.println("Channel Name :"
                + ChannelName + ", Status : "
                + Status + " New video posted...Notifying all Registered users ");
        System.out.println();
		fans.forEach(	(fan) -> fan.update(Status)	);
	}

	// constructor
	public Channel(String channelname, String status) {
        this.ChannelName = channelname;
        this.Status = status;
    }

	// Status getter and setter
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		this.Status = status;
		System.out.println("Status updated");
		NotifyObservers();
	}

}
