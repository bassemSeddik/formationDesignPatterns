module observer {
	exports ownObserver;
	exports javaUtilObserver;
	requires java.desktop;
}