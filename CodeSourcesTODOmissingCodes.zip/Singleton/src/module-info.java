module Singleton {
}