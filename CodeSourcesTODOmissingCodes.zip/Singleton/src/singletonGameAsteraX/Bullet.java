package singletonGameAsteraX;

public class Bullet {
	
	public Bullet() {
		System.out.println("*** Creation of Bullets set ***");
	}
}
