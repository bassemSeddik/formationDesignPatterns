package singletonGameAsteraX;

public class SingletonGameManagerAsterax {// lazy construction

	public static final int NUMBER_ASTOIDS = 3;
	public static final int SPEED = 3;
	public static final int SIZE = 3;

	// the class variable is null if no instance is instantiated
	private static SingletonGameManagerAsterax _UniqueInstance = null;

	private SingletonGameManagerAsterax() {

	}

	// lazy construction of the instance
	public static SingletonGameManagerAsterax getInstance() {
		if (_UniqueInstance == null) {
			_UniqueInstance = new SingletonGameManagerAsterax();
		}
		return _UniqueInstance;
	}
}
