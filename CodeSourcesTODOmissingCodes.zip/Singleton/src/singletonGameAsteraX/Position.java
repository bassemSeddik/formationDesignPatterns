package singletonGameAsteraX;

public class Position {
	public  float x;
	public  float y;
	public Position(float x, float y) {
		super();
		this.x = x;
		this.y = y;
	}
	
}
