package youtubeObserver;

public class Program {
	public static void main(String[] args) {
		//Create new channel without new videos
        Channel observedChannel = new Channel("Daft_Punk", "didn't post any new videos");
        //User Ahmed will be created and user1 object will be registered to the channel
        Observer user1 = new Follower("Laurent", observedChannel);
        //User Aziz will be created and user2 object will be registered to the channel
        Observer user2 = new Follower("Aminou", observedChannel);
        //User Anis will be created and user3 object will be registered to the channel
        Observer user3 = new Follower("Dora", observedChannel);
        
        System.out.println("Videos update : " + observedChannel.getStatus());
        System.out.println();
        // DP channel posted a new video
        observedChannel.setStatus(">A new Song is Rocking: ... Around the World! Around the World!");
	}
}
