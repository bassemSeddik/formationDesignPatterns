package youtubeObserver;

public class Follower implements Observer{
	public String UserName;
	
    public Follower(String userName, Subject channel) {
        UserName = userName;
        channel.RegisterObserver(this);
    }
    
    public void update(String content) {
        System.out.println("Hello " + UserName + ", the channel posted a new video \n" + content);
    }
}
