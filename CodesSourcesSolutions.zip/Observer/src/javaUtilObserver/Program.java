package javaUtilObserver;

//import static org.junit.Assert.assertEquals;

public class Program {
	public static void main(String[] args) {
		ONewsAgency myObservable = new ONewsAgency();
		ONewsChannel myObserver = new ONewsChannel();

		myObservable.addObserver(myObserver);
		myObservable.setNews("The new satellite AAA has been lauched!");
		myObservable.setNews("The elected president goes here and there!");
		//assertEquals(myObserver.getNews(), "news");
		System.out.println(myObserver.getNews().toString());
	}
}
