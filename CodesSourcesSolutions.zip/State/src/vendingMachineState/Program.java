package vendingMachineState;

public class Program {

	public static void main(String[] args) {
		VendingMachine myVend1 = new VendingMachine(3);
        myVend1.displayState();
        myVend1.ejectMoney();
        myVend1.insertDollar();
        myVend1.dispense();
        
        // We have two pieces in this machine
        VendingMachine myVend2 = new VendingMachine(0);
        myVend2.displayState();
	}

}
