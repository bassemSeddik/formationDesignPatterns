package vendingMachineState;

public class IdleState implements State {

	/**
	 * If: We are on the IdleState, and the insertDollar() is Triggered Then: The
	 * machine transitions to the HasOnDollarState State
	 */
	public void insertDollar(VendingMachine vendingMachine) {
		System.out.println(">You just iserted money");
		vendingMachine.getHasOnDollarState();
	}

	/**
	 * If: We are on the IdleState, and the ejectMoney() is Triggered Then: The
	 * machine stays here and outputs a message!
	 */
	public void ejectMoney(VendingMachine vendingMachine) {
		System.out.println(">No money to return");
	}

	/**
	 * If: We are on the IdleState, and the dispense() is Triggered Then: The
	 * machine stays here and outputs a message!
	 */
	public void dispense(VendingMachine vendingMachine) {
		System.out.println(">We cannot dispense, you have to insert money first");
	}
}
