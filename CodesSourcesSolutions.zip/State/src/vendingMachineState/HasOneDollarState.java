package vendingMachineState;

public class HasOneDollarState implements State {
	/**
	 * If: We are on the HasOneDollarState, and the insertDollar() is Triggered
	 * Then: The machine stays here and outputs a message!
	 */
	public void insertDollar(VendingMachine vendingMachine) {
		System.out.println(">There is already money in the machine!");
		// the following might not be necessary as we may stay in the same state
		vendingMachine.ejectMoney();
		vendingMachine.setState(vendingMachine.getIdleState());
	}

	/**
	 * If: We are on the HasOneDollarState, and the ejectMoney() is Triggered Then:
	 * The machine stays here and outputs a message!
	 */
	public void ejectMoney(VendingMachine vendingMachine) {
		System.out.println(">Here is you money back");
		vendingMachine.ejectMoney();
		vendingMachine.setState(vendingMachine.getIdleState());
	}

	/**
	 * If: We are on the HasOneDollarState, and the dispense() is Triggered Then:
	 * The machine make one of two choices!
	 */
	public void dispense(VendingMachine vendingMachine) {
		System.out.println(">Your product is delived, check it down ->");
		if (vendingMachine.getCount() > 1) {
			vendingMachine.doReturnMoney();
			vendingMachine.setState(vendingMachine.getIdleState());
		} else {
			vendingMachine.doReleaseProduct();
			vendingMachine.setState(vendingMachine.getOutOfStockState());
		}
	}
}
