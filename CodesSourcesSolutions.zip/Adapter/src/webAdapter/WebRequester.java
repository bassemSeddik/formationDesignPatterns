package webAdapter;

public interface WebRequester {
	public int request(Object object);
}
