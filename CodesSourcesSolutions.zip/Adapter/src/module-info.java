module Adapter {
	exports webAdapter;

	requires json.simple;
}