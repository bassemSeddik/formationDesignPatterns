package pasta;

public  class SpaghettiWithMeatBalls extends PastaDish{
	public SpaghettiWithMeatBalls() {
		System.out.println("|_ NEW Penne Spaghetti With Meat Balls DISH");
	}
	@Override
	protected void AddPasta()
    {
		System.out.println("SpaghettiWithMeatBalls-> Now we add the Spaghetti ");
    }
	@Override
    protected void AddSauce()
    {
		System.out.println("SpaghettiWithMeatBalls-> Now we add the Tomato Sauce");
    }
	@Override
    protected void AddProtein()
    {
		System.out.println("SpaghettiWithMeatBalls-> Here we Add the Meat Balls");
    }
	@Override
    protected void AddGarnish()
    {
		System.out.println("SpaghettiWithMeatBalls-> And last touch: Add the Parmesan Cheese :)");
    }
}
