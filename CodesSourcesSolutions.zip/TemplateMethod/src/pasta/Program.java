package pasta;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in); 
		System.out.println(" ----------- your menu for today is ------------ ");
		System.out.println("|\t 1) Spaghetti With Meat Balls \t\t|");
		System.out.println("|\t 2) Penne Alfredo \t\t\t|");
		System.out.println(" ----------------------------------------------- ");
		System.out.println("Please type your choice number");
		int dish = 0;
		while ((dish != 1) && (dish != 2)) {
			dish  = sc.nextInt();
			System.out.println("your choice is " + dish);
		}
		if (dish == 1) {
			SpaghettiWithMeatBalls mySpaghetti = new SpaghettiWithMeatBalls();
	        mySpaghetti.makeRecipe();
		}
		else if (dish == 2) {
			PenneAlfredo myPenne = new PenneAlfredo();
			myPenne.makeRecipe();
		}
	}
}
