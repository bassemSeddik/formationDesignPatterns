package pasta;

public class PenneAlfredo extends PastaDish{
	
	public PenneAlfredo() {
		System.out.println("|_ NEW Penne Alfredo DISH");
	}
	@Override
	protected void AddPasta()
    {
        System.out.println( "PenneAlfredo-> Now we add the PENNE ");
    }
	@Override
    protected  void AddSauce()
    {
		System.out.println("PenneAlfredo-> Now we add the ALFREDO Sauce");
    }
	@Override
    protected  void AddProtein()
    {
		System.out.println("PenneAlfredo-> Here we Add the CHICKEN ");
    }
	@Override
    protected  void AddGarnish()
    {
		System.out.println("PenneAlfredo-> And last touch: Add the PARSELY :)");
    }
}
