module TemplateMethod {
}