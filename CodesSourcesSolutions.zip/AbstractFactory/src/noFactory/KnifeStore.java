package noFactory;

public class KnifeStore { 
	// C'est l'�quivalent de notre programme principal qui pourra cr�er diff�rente
	// knives de diff�rents types et puis les manipuler pour les vendre apr�s, par exp.
	public static Knife OrderKnife(String knifeType) {
		Knife knife = null;
		
		//create concrete Knife
		if (knifeType.equals("cheeze")) {
			knife = new ExampleCheezeKnife();
		} 
		else if (knifeType.equals("bread")) {
			knife = new ExampleChefsKnife();
		} 
		else if (knifeType.equals("chefs")) {
			knife = new ExampleBreadKnife();
		} 
		else if (knifeType.equals("cakes")) {
			knife = new ExampleCakesKnife();
		}
		else return null;
		
		knife.Sharpen();
		knife.Polish();
		knife.Pack();
		
		return knife;
	}
	
	public static void main(String[] args) {
		OrderKnife("chefs");
		OrderKnife("steak");
		OrderKnife("cakes");
		OrderKnife("bread");
	}
}
