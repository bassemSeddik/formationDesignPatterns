package noFactory;

public class ExampleBreadKnife extends Knife {
	
	public void Sharpen() {
		System.out.println("The BreadKnife is Sharpened");
	}

	public void Polish() {
		System.out.println("The BreadKnife is Polished");
	}

	public void Pack() {
		System.out.println("The BreadKnife is Packed");
	}

	public ExampleBreadKnife() {
		super();
		System.out.println("------------- A BreadKnife -----------");

	}

}
