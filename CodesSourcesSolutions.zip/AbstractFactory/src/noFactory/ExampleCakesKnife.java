package noFactory;

public class ExampleCakesKnife extends Knife {
	public void Sharpen() {
		System.out.println("The CakesKnife is Sharpened");
	}
	
	public void Polish() {
		System.out.println("The CakesKnife is Polished");
	}
	
	public void Pack() {
		System.out.println("The CakesKnife is Packed");
	}

	public ExampleCakesKnife() {
		super();
		System.out.println("------------- A CakesKnife-----------");
	}
}
