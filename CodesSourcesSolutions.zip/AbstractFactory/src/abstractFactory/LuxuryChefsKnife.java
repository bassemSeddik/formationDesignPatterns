package abstractFactory;

public class LuxuryChefsKnife extends Knife {
	public void Sharpen() {
		System.out.println("The LuxuryChefsKnife is Sharpened");
	}
	
	public void Polish() {
		System.out.println("The LuxuryChefsKnife is Polished");
	}
	
	public void Pack() {
		System.out.println("The LuxuryChefsKnife is Packed");
	}

	public LuxuryChefsKnife() {
		super();
		System.out.println("------------- A LuxuryChefsKnife -----------");
	}
}
