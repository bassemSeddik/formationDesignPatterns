package abstractFactory;

public abstract class AbstractKnifeFactory {

	abstract Knife createKnife (String type);
	
}
