package abstractFactory;

public class LuxuryKnifeStore {
	private LuxuryKnifeFactory luxuryFactory;
	public LuxuryKnifeStore(LuxuryKnifeFactory luxfact01) {
		this.setLuxuryFactory(luxfact01);
	}

	public LuxuryKnifeFactory getLuxuryFactory() {
		return luxuryFactory;
	}
	public void setLuxuryFactory(LuxuryKnifeFactory luxfact01) {
		this.luxuryFactory = luxfact01;
	}
	
	public Knife orderKnife(String knifeType) {
		Knife knife;
		// now creating a knife is a method in the class 
		knife = luxuryFactory.createKnife(knifeType);
		
		knife.Sharpen();
		knife.Polish();
		knife.Pack();
		return knife;
	}
	
}
