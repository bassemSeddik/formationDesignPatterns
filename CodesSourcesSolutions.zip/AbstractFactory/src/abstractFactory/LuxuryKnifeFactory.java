package abstractFactory;

public class LuxuryKnifeFactory extends AbstractKnifeFactory{
	
	@Override
	Knife createKnife(String knifeType) {
		// up to any subclass of BudgetKnifeStore to define this method
		if (knifeType.equals("cakes")) {
			return new LuxuryCakeKnife();
		} else if (knifeType.equals("chefs")) {
			return new LuxuryChefsKnife();
		}
		// .. more types
		else
			return null;
	}
}
