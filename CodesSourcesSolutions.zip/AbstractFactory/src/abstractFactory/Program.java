package abstractFactory;

public class Program {

	public static void main(String[] args) {
		LuxuryKnifeFactory luxfact01 = new LuxuryKnifeFactory();
		LuxuryKnifeStore luxStore01 = new LuxuryKnifeStore(luxfact01);
		
		BudgetKnifeFactory bugetFact02 = new BudgetKnifeFactory();
		BudgetKnifeStore bugetStore02 = new BudgetKnifeStore(bugetFact02);
		
		luxStore01.orderKnife("chefs");
		luxStore01.orderKnife("cakes");
		
		bugetStore02.orderKnife("cheeze");
		bugetStore02.orderKnife("bread");
	}
}
