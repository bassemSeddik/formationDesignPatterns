package factoryMethod;

public class Knife {
	protected Knife() {
		System.out.println("\t --> A new knife is created: ");
	}
	
	public void Sharpen() {
		System.out.println("The Knife is Sharpened");
	}
	
	public void Polish() {
		System.out.println("The Knife is Polished");
	}
	
	public void Pack() {
		System.out.println("The Knife is Packed");
	}
}
