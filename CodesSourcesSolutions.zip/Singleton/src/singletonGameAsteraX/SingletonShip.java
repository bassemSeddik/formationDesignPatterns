package singletonGameAsteraX;

public class SingletonShip {

	private static SingletonShip _SingletonShip;
	Bullet bullets;

	private SingletonShip() {
		// set_SingletonShip(this._SingletonShip);
		 this.bullets = new Bullet();
	}

	public void FireBullets() {
		if (bullets != null) {
			System.out.printf("\tPfew! ");
			for (int i = 0; i < 10; i++) {
				System.out.printf("= ");
			}
			System.out.printf("\n");
		}
	}

	// Call to the default generated getter
	public static SingletonShip get_SingletonShip() {
		if (_SingletonShip == null) {
			System.out.println("\nThe FIRST ship instance is created");
			_SingletonShip = new SingletonShip();
		} else {
			System.out.println("Second ship instance creation refused \n |_rediretion to existing instance");
		}
		return _SingletonShip;
	}

	// the test logic on the unique instance is placed in the Setter in this case
//	public static void set_SingletonShip(SingletonShip _SingletonShip) {
//		if (_SingletonShip != null)	{
//			System.out.println("Second attempt to set PlayerShip singleton, NOT allowed \n");
//		}
//		else {
//			SingletonShip._SingletonShip = _SingletonShip;
//			System.out.println("The FIRST instance is created");
//		}
//	}
}
