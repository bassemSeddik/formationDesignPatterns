package singletonGameAsteraX;

public class Astroid {
	public int size;
	public float speed;
	public Position position;
	
	public Astroid(int size, float speed, Position position) {
		this.size = size;
		this.speed = speed;
		this.position = position;
		System.out.printf(">Creation of and Astroid of size %d and speed %f \n", size, speed);
	}
}
