package singletonGameAsteraX;

public class Program {

	public static void main(String[] args) {
		
		Position pos1 = new Position(3, 2);
		Astroid astroid1 = new Astroid(	SingletonGameManagerAsterax.SIZE, 
										SingletonGameManagerAsterax.SPEED, 
										pos1);
		
		Position pos2 = new Position(15, 20);
		Astroid astroid2 = new Astroid(	SingletonGameManagerAsterax.SIZE-1, 
										SingletonGameManagerAsterax.SPEED+10, 
										pos2);
		
		//SingletonShip myShip1 = new SingletonShip();
		//SingletonShip myShip2 = new SingletonShip();
		SingletonShip myShip1 = SingletonShip.get_SingletonShip();
		SingletonShip myShip2 = SingletonShip.get_SingletonShip();
		
		myShip1.FireBullets();
		myShip2.FireBullets();
		
	}

}
