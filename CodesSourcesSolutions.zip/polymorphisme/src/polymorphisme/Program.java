package polymorphisme ;

public class Program {
	public static void main(String[] args) {
		Chat chat1 = new Chat("Minou");
		Chien chien1 = new Chien("Medor");

		chat1.Parler();
		chien1.Parler();
	}
}
