package facadeClientAccount;

import java.math.BigDecimal;

public class Investment implements IAccount {
	private BigDecimal moneyAmount;
	private int accountNumber;
	
	/**
	 * The getters and setters for the moneyAccount
	 */
	public BigDecimal getMoneyAmount() {
		return moneyAmount;
	}
	public void setMoneyAmount(BigDecimal moneyAmount) {
		this.moneyAmount = moneyAmount;
	}
	
	/**
	 * The getters and setters for the Account number
	 */
	@Override
	public int getAccountNumber() {
		return this.accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		System.out.printf("The Investment Account number is %d\n", getAccountNumber());
		this.accountNumber = accountNumber;
	}
	
	// The constructor
		public Investment (BigDecimal intiAmount) {
			this.setMoneyAmount(intiAmount);
			System.out.println("Investment Account CREATION");
			System.out.println("\tActual money is: " + this.moneyAmount.toString());
		}
		
	@Override
	public void deposit(BigDecimal amount) {
		System.out.println("Investment Account Deposit of money");
		this.moneyAmount = this.moneyAmount.add(amount);
		System.out.println("\t Added "+ amount.toString()+" Actual money is: " + this.moneyAmount.toString());
	}

	@Override
	public void withdraw(BigDecimal amount) {
		System.out.println("Investment Account Withdrawal of money");
		this.moneyAmount = this.moneyAmount.subtract(amount);
		System.out.println("\tSubracted "+ amount.toString()+ " Actual money is: " + this.moneyAmount.toString());
	}

	@Override
	public void transfer(BigDecimal amount) {
		System.out.println("Investment Account Transfer of money");
		this.moneyAmount = this.moneyAmount.subtract(amount);
		System.out.println("\tSubracted "+ amount.toString()+" Actual money is: " + this.moneyAmount.toString());
	}

}