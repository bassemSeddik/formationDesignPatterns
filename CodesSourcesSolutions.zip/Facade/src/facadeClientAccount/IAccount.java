package facadeClientAccount;

import java.math.BigDecimal;

/**
 * The BigDecimal data-type is used to represent money in financial applications
 * It solves the lack of precision problems in "float" and "double" data-types 
 * when applying statistical calculations 
 */
public interface IAccount {
	
	public void deposit(BigDecimal amount);
	public void withdraw(BigDecimal amount);
	public void transfer(BigDecimal amount);
	public int getAccountNumber();
}
